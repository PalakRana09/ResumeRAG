# ResumeRAG - Django (Hackathon-ready)
A minimal Django project for resume upload and job-match ranking using TF-IDF (scikit-learn).

## Features
- Upload resumes (plain .txt files) or paste resume text in web form
- Store resumes in SQLite (Django default)
- Search / Job Match: paste job description, returns ranked resumes with fit scores (cosine similarity on TF-IDF)
- Simple HTML frontend using Django templates

## Quick start
1. Create virtualenv and install requirements:
   ```bash
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
2. Run migrations:
   ```bash
   python manage.py migrate
   ```
3. Create superuser (optional):
   ```bash
   python manage.py createsuperuser
   ```
4. Run the dev server:
   ```bash
   python manage.py runserver
   ```
5. Open your browser at http://127.0.0.1:8000/ and use Upload → Job Match.

## Notes & Improvements
- This minimal hackathon-ready project accepts .txt resume uploads and pasted text.
- To support PDF/DOCX resume parsing, add `pdfplumber` / `python-docx` and processing code.
- For production, change SECRET_KEY, DEBUG=False, and configure static/media hosting.
