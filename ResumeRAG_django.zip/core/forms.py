from django import forms
from .models import Resume

class ResumeForm(forms.ModelForm):
    paste_text = forms.CharField(widget=forms.Textarea(attrs={{'rows':6}}), required=False, label='Or paste resume text')

    class Meta:
        model = Resume
        fields = ['name', 'email', 'file', 'text']

    def clean(self):
        cleaned = super().clean()
        file = cleaned.get('file')
        text = cleaned.get('text') or self.data.get('paste_text')
        if not file and not text:
            raise forms.ValidationError('Please upload a .txt resume OR paste the resume text.')
        # If paste_text present, put into text field
        if self.data.get('paste_text'):
            cleaned['text'] = self.data.get('paste_text')
        return cleaned
