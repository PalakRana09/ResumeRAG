from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('upload/', views.upload_resume, name='upload_resume'),
    path('resumes/', views.list_resumes, name='list_resumes'),
    path('search/', views.search_view, name='search_view'),
]
