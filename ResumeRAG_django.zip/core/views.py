from django.shortcuts import render, redirect
from .forms import ResumeForm
from .models import Resume
from django.conf import settings
import os

# For text search
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def home(request):
    return render(request, 'home.html')

def upload_resume(request):
    if request.method == 'POST':
        form = ResumeForm(request.POST, request.FILES)
        if form.is_valid():
            resume = form.save(commit=False)
            # if file is provided and is .txt, read it
            f = request.FILES.get('file')
            if f and f.name.lower().endswith('.txt'):
                text = f.read().decode('utf-8', errors='ignore')
                resume.text = text
            resume.save()
            return redirect('list_resumes')
    else:
        form = ResumeForm()
    return render(request, 'upload.html', {{'form': form}})

def list_resumes(request):
    resumes = Resume.objects.order_by('-uploaded_at')
    return render(request, 'list.html', {{'resumes': resumes}})

def search_view(request):
    results = []
    query = ''
    if request.method == 'POST':
        query = request.POST.get('query', '').strip()
        resumes = Resume.objects.all()
        corpus = [r.text or '' for r in resumes]
        names = [r.name for r in resumes]
        ids = [r.id for r in resumes]
        # if no resumes, return empty
        if any(corpus):
            docs = corpus + [query]
            vectorizer = TfidfVectorizer(stop_words='english', max_features=2000)
            tfidf = vectorizer.fit_transform(docs)
            query_vec = tfidf[-1]
            doc_vecs = tfidf[:-1]
            sims = cosine_similarity(doc_vecs, query_vec).flatten()
            for idx, score in enumerate(sims):
                results.append({{
                    'id': ids[idx],
                    'name': names[idx],
                    'score': float(score),
                    'snippet': (corpus[idx][:300] + '...') if len(corpus[idx])>300 else corpus[idx]
                }})
            # sort by score desc
            results = sorted(results, key=lambda x: x['score'], reverse=True)
    return render(request, 'search.html', {{'results': results, 'query': query}})
